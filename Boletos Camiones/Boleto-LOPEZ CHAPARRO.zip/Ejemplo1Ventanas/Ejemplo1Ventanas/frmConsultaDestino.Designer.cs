﻿
namespace ProyBoletos
{
    partial class frmConsultaDestino
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblClaves = new System.Windows.Forms.Label();
            this.cmbClaves = new System.Windows.Forms.ComboBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.txtCosto = new System.Windows.Forms.TextBox();
            this.lblTrayecto = new System.Windows.Forms.Label();
            this.txtTrayecto = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblClaves
            // 
            this.lblClaves.AutoSize = true;
            this.lblClaves.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClaves.Location = new System.Drawing.Point(62, 59);
            this.lblClaves.Name = "lblClaves";
            this.lblClaves.Size = new System.Drawing.Size(66, 25);
            this.lblClaves.TabIndex = 0;
            this.lblClaves.Text = "Claves";
            this.lblClaves.Click += new System.EventHandler(this.label1_Click);
            // 
            // cmbClaves
            // 
            this.cmbClaves.FormattingEnabled = true;
            this.cmbClaves.Location = new System.Drawing.Point(134, 64);
            this.cmbClaves.Name = "cmbClaves";
            this.cmbClaves.Size = new System.Drawing.Size(121, 21);
            this.cmbClaves.TabIndex = 1;
            this.cmbClaves.SelectedIndexChanged += new System.EventHandler(this.cmbClaves_SelectedIndexChanged);
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Goudy Old Style", 16F);
            this.lblNombre.Location = new System.Drawing.Point(62, 111);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(84, 26);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(65, 140);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.ReadOnly = true;
            this.txtNombre.Size = new System.Drawing.Size(153, 20);
            this.txtNombre.TabIndex = 2;
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Goudy Old Style", 16F);
            this.lblCosto.Location = new System.Drawing.Point(62, 175);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(64, 26);
            this.lblCosto.TabIndex = 0;
            this.lblCosto.Text = "Costo";
            // 
            // txtCosto
            // 
            this.txtCosto.Location = new System.Drawing.Point(63, 204);
            this.txtCosto.Name = "txtCosto";
            this.txtCosto.ReadOnly = true;
            this.txtCosto.Size = new System.Drawing.Size(83, 20);
            this.txtCosto.TabIndex = 2;
            // 
            // lblTrayecto
            // 
            this.lblTrayecto.AutoSize = true;
            this.lblTrayecto.Font = new System.Drawing.Font("Goudy Old Style", 16F);
            this.lblTrayecto.Location = new System.Drawing.Point(62, 241);
            this.lblTrayecto.Name = "lblTrayecto";
            this.lblTrayecto.Size = new System.Drawing.Size(166, 26);
            this.lblTrayecto.TabIndex = 0;
            this.lblTrayecto.Text = "Tiempo  Trayecto";
            // 
            // txtTrayecto
            // 
            this.txtTrayecto.Location = new System.Drawing.Point(65, 270);
            this.txtTrayecto.Name = "txtTrayecto";
            this.txtTrayecto.ReadOnly = true;
            this.txtTrayecto.Size = new System.Drawing.Size(100, 20);
            this.txtTrayecto.TabIndex = 2;
            // 
            // frmConsultaDestino
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 322);
            this.Controls.Add(this.txtTrayecto);
            this.Controls.Add(this.lblTrayecto);
            this.Controls.Add(this.txtCosto);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblCosto);
            this.Controls.Add(this.cmbClaves);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblClaves);
            this.Name = "frmConsultaDestino";
            this.Text = "Consulta Destino";
            this.Load += new System.EventHandler(this.FrmConsultaDestino_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblClaves;
        private System.Windows.Forms.ComboBox cmbClaves;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.TextBox txtCosto;
        private System.Windows.Forms.Label lblTrayecto;
        private System.Windows.Forms.TextBox txtTrayecto;
    }
}