﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyBoletos
{
    public partial class frmConsultaDestino : Form
    {
        AdmDestino destinos;
        public frmConsultaDestino(AdmDestino dest)
        {
            InitializeComponent();
            destinos = dest;
        }

        private void FrmConsultaDestino_Load(object sender, EventArgs e)
        {
            // Voy a cargar el combobox con las claves de los destinos
            CargaDestinos();

        }

        public void CargaDestinos()
        {
            string[] cvesDestinos = destinos.ObtenClavesDestino();
            for (int i = 0; i < cvesDestinos.Length; i++)
            {
                cmbClaves.Items.Add(cvesDestinos[i]);
            }
        }

        private void cmbClaves_SelectedIndexChanged(object sender, EventArgs e)
        {
            string claveSeleccionada = cmbClaves.SelectedItem.ToString();
            Destino destinoSel = destinos.ObtenDestino(claveSeleccionada);
            txtNombre.Text = destinoSel.pNombreDestino;
            txtCosto.Text = Convert.ToString(destinoSel.pCostoDestino);
            txtTrayecto.Text = Convert.ToString(destinoSel.pTiempoTrayecto);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
