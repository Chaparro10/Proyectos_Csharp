﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyBoletos
{
    public partial class frmVentaBoletos : Form
    {
        AdmBoletos boletos;
        AdmDestino destinos;
       

        public frmVentaBoletos(AdmBoletos bol ,AdmDestino ad)
        {
            InitializeComponent();
            boletos= bol;
            destinos = ad;

        }

        private void btnGuardar_Click(object sender, EventArgs e)

        {
            int numBoleto = Convert.ToInt32(txtNumeroBoleto.Text);
            string claveD = cmbDestino.SelectedItem.ToString();
            double costoBoleto = RegresaCosto();
            byte numAsiento = Convert.ToByte(numUpAsiento);
            //char TipoBoleto = TipoBoleto;
            //char tipoboleto = Convert.ToSByte();

            string nombrePasajero = txtNombrePasajero.Text;

            AdmBoletos.AgregarBoleto(numBoleto,claveD,costoBoleto,nombrePasajero,
                numAsiento,tipoboleto);
        }
        public double RegresaCosto()
        {
            double Costo = Convert.ToDouble(txtCosto.Text);
            if (rdEstudiante.Checked)
            {
                Costo = Costo-(Costo * 0.15);
            }
            return Costo;
        }

        private void rdNormal_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmVentaBoletos_Load(object sender, EventArgs e)
        {
            //1 Cargar el numero de boleto 
            txtNumeroBoleto.Text = Boleto.pNumeroBoleto.ToString();
            

            //2 Cargar el Combo con los destinos
            CargaDestinos();
            cmbDestino.SelectedIndex = 0;
            ObtenDatosDestino();
        }

        //Metodo Cargar Destinos
        public void CargaDestinos()
        {
            string[] cvesDestinos = destinos.ObtenClavesDestino();
            for (int i = 0; i < cvesDestinos.Length; i++)
            {
                cmbDestino.Items.Add(cvesDestinos[i]);
            }
        }
        //METODO PARA OBTENER DATOS DEL DESTINO
        public void ObtenDatosDestino()
        {
            string clave = cmbDestino.SelectedItem.ToString();
            Destino destino = destinos.ObtenDestino(clave);
            txtCosto.Text = Convert.ToInt32(destino.pCostoDestino).ToString() ;
            txtDuracion.Text = destino.pTiempoTrayecto.ToString();
            lblNombreDestino.Text = destino.pNombreDestino;
          

        }

        //ComboBox Destino
        private void cmbDestino_SelectedIndexChanged(object sender, EventArgs e)
        {
            ObtenDatosDestino();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            //Limpiar los Componentes
            Limpiar();
            //Volver a dejar el elemento cero seleccionado del combobox en 0
            cmbDestino.SelectedIndex = 0;
            ObtenDatosDestino();
        }

        public void Limpiar()
        {
            //txtClave.Text = " ";
            //txtCosto.Text = " ";
            //txtNombre.Text = " ";
            txtCosto.Text = "";
            txtDuracion.Text = "";
            txtNombrePasajero.Text = "";
            txtNumeroBoleto.Text = "";
            

        }
    }
}
