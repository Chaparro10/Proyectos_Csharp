﻿using System;

namespace ProyBoletos
{
    public class Boleto
    {
        private int NumBoletoAsignado;
        private string ClaveDestino;
        private double Costo;
        private string NombrePasajero;
        private byte NumeroAsiento;
        private char TipoBoleto;

        private static int NumeroBoleto = 1000;
        //Constructor
        public Boleto(int NumBoleto,string ClaveD, double costo, 
            string Nombrepasajero,byte NumAsiento,char tipoboleto)
        {
            NumBoletoAsignado = NumBoleto;
            ClaveDestino = ClaveD;
            Costo = costo;
            NombrePasajero = Nombrepasajero;
            NumeroAsiento = NumAsiento;
            TipoBoleto = tipoboleto;
        }
        //Propiedades
        public int pNumBoletoAsignado
        {
            get
            {
                return NumBoletoAsignado;
            }
        }
        public string pClaveDestino
        {
            get
            {
                return ClaveDestino;
            }
        }
        public double pCosto
        {
            get
            {
                return Costo;
            }
        }
        public string pNombrePasajero
        {
            get
            {
                return NombrePasajero;
            }
        }
        public byte pNumeroAsiento
        {
            get
            {
                return NumeroAsiento;
            }
        }
       public char pTipoBoleto
        {
            get
            {
                return TipoBoleto;
            }
        }
        public static int pNumeroBoleto
        {
            get
            {
                return NumeroBoleto;
            }
        }
    }

    }

