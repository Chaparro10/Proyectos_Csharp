﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyBoletos
{
    public class AdmBoletos
    {
        private List<Boleto> listBoletos = new List<Boleto>();

        public void AgregarBoleto(int numBoleto,string claveD,double costoBoleto,string nombrePasajero,
            byte NumAsiento, char tipoboleto)
        {
           

            //Agregar al List

            listBoletos.Add(new Boleto(numBoleto,claveD,costoBoleto,nombrePasajero,NumAsiento,tipoboleto));
        }
    }
}
