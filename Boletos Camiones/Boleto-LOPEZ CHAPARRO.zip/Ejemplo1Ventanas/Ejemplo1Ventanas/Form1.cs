﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyBoletos
{
    public partial class Form1 : Form
    {
        AdmDestino destino;
        AdmBoletos boletos;
        
        public Form1(AdmDestino adm,AdmBoletos bol)
        {
            InitializeComponent();
            destino = adm;
            boletos = bol;
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            //obtener los datos de los componentes
            string claveD = txtClave.Text;

            if (destino.BuscaClave(claveD)==false)
            {
                string nombreD = txtNombre.Text;
                int costoD = Convert.ToInt32(txtCosto.Text);
                string tiempo = cmbTrayecto.SelectedItem.ToString();
               
                // como puedo convertir a double 
                destino.AgregarDestino(claveD, nombreD, costoD, 1.5);
                MessageBox.Show(" Exito al Agregar", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar();
            }
            else
            {
                MessageBox.Show("Error al Agregar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        private void Limpiar()
        {
            txtClave.Text = " ";
            txtCosto.Text = " ";
            txtNombre.Text = " ";
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            frmConsultaDestino consultaDestino = new frmConsultaDestino(destino);
            consultaDestino.ShowDialog();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
       
        private void btnIrVentas_Click(object sender, EventArgs e)
        {
            frmVentaBoletos ventaBoletos = new frmVentaBoletos(boletos,destino);
            ventaBoletos.ShowDialog();
        }

       
        }
    }
}
