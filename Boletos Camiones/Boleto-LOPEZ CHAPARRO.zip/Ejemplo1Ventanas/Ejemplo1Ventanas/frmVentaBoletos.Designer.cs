﻿namespace ProyBoletos
{
    partial class frmVentaBoletos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rdNormal = new System.Windows.Forms.RadioButton();
            this.rdEstudiante = new System.Windows.Forms.RadioButton();
            this.gbTipoBoleto = new System.Windows.Forms.GroupBox();
            this.lblNumBoleto = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.txtNumeroBoleto = new System.Windows.Forms.TextBox();
            this.cmbDestino = new System.Windows.Forms.ComboBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblDuracion = new System.Windows.Forms.Label();
            this.txtCosto = new System.Windows.Forms.TextBox();
            this.txtDuracion = new System.Windows.Forms.TextBox();
            this.lblNombrePasajero = new System.Windows.Forms.Label();
            this.lblAsiento = new System.Windows.Forms.Label();
            this.numUpAsiento = new System.Windows.Forms.NumericUpDown();
            this.txtNombrePasajero = new System.Windows.Forms.TextBox();
            this.gbDestino = new System.Windows.Forms.GroupBox();
            this.lblNombreDestino = new System.Windows.Forms.Label();
            this.gbTipoBoleto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpAsiento)).BeginInit();
            this.gbDestino.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // rdNormal
            // 
            this.rdNormal.AutoSize = true;
            this.rdNormal.Location = new System.Drawing.Point(0, 19);
            this.rdNormal.Name = "rdNormal";
            this.rdNormal.Size = new System.Drawing.Size(58, 17);
            this.rdNormal.TabIndex = 1;
            this.rdNormal.TabStop = true;
            this.rdNormal.Text = "Normal";
            this.rdNormal.UseVisualStyleBackColor = true;
            this.rdNormal.CheckedChanged += new System.EventHandler(this.rdNormal_CheckedChanged);
            // 
            // rdEstudiante
            // 
            this.rdEstudiante.AutoSize = true;
            this.rdEstudiante.Location = new System.Drawing.Point(116, 19);
            this.rdEstudiante.Name = "rdEstudiante";
            this.rdEstudiante.Size = new System.Drawing.Size(75, 17);
            this.rdEstudiante.TabIndex = 2;
            this.rdEstudiante.TabStop = true;
            this.rdEstudiante.Text = "Estudiante";
            this.rdEstudiante.UseVisualStyleBackColor = true;
            // 
            // gbTipoBoleto
            // 
            this.gbTipoBoleto.Controls.Add(this.rdNormal);
            this.gbTipoBoleto.Controls.Add(this.rdEstudiante);
            this.gbTipoBoleto.Location = new System.Drawing.Point(12, 213);
            this.gbTipoBoleto.Name = "gbTipoBoleto";
            this.gbTipoBoleto.Size = new System.Drawing.Size(200, 49);
            this.gbTipoBoleto.TabIndex = 3;
            this.gbTipoBoleto.TabStop = false;
            this.gbTipoBoleto.Text = "Tipo Boleto";
            // 
            // lblNumBoleto
            // 
            this.lblNumBoleto.AutoSize = true;
            this.lblNumBoleto.Location = new System.Drawing.Point(16, 9);
            this.lblNumBoleto.Name = "lblNumBoleto";
            this.lblNumBoleto.Size = new System.Drawing.Size(77, 13);
            this.lblNumBoleto.TabIndex = 4;
            this.lblNumBoleto.Text = "Numero Boleto";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(306, 70);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 5;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(306, 120);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 6;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(306, 178);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 7;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            // 
            // txtNumeroBoleto
            // 
            this.txtNumeroBoleto.Location = new System.Drawing.Point(15, 25);
            this.txtNumeroBoleto.Name = "txtNumeroBoleto";
            this.txtNumeroBoleto.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroBoleto.TabIndex = 8;
            // 
            // cmbDestino
            // 
            this.cmbDestino.FormattingEnabled = true;
            this.cmbDestino.Location = new System.Drawing.Point(6, 19);
            this.cmbDestino.Name = "cmbDestino";
            this.cmbDestino.Size = new System.Drawing.Size(78, 21);
            this.cmbDestino.TabIndex = 10;
            this.cmbDestino.SelectedIndexChanged += new System.EventHandler(this.cmbDestino_SelectedIndexChanged);
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Location = new System.Drawing.Point(6, 54);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(34, 13);
            this.lblCosto.TabIndex = 11;
            this.lblCosto.Text = "Costo";
            // 
            // lblDuracion
            // 
            this.lblDuracion.AutoSize = true;
            this.lblDuracion.Location = new System.Drawing.Point(64, 54);
            this.lblDuracion.Name = "lblDuracion";
            this.lblDuracion.Size = new System.Drawing.Size(50, 13);
            this.lblDuracion.TabIndex = 12;
            this.lblDuracion.Text = "Duracion";
            // 
            // txtCosto
            // 
            this.txtCosto.Location = new System.Drawing.Point(1, 70);
            this.txtCosto.Name = "txtCosto";
            this.txtCosto.Size = new System.Drawing.Size(60, 20);
            this.txtCosto.TabIndex = 13;
            // 
            // txtDuracion
            // 
            this.txtDuracion.Location = new System.Drawing.Point(67, 70);
            this.txtDuracion.Name = "txtDuracion";
            this.txtDuracion.Size = new System.Drawing.Size(100, 20);
            this.txtDuracion.TabIndex = 14;
            // 
            // lblNombrePasajero
            // 
            this.lblNombrePasajero.AutoSize = true;
            this.lblNombrePasajero.Location = new System.Drawing.Point(12, 156);
            this.lblNombrePasajero.Name = "lblNombrePasajero";
            this.lblNombrePasajero.Size = new System.Drawing.Size(88, 13);
            this.lblNombrePasajero.TabIndex = 15;
            this.lblNombrePasajero.Text = "Nombre Pasajero";
            // 
            // lblAsiento
            // 
            this.lblAsiento.AutoSize = true;
            this.lblAsiento.Location = new System.Drawing.Point(125, 156);
            this.lblAsiento.Name = "lblAsiento";
            this.lblAsiento.Size = new System.Drawing.Size(42, 13);
            this.lblAsiento.TabIndex = 16;
            this.lblAsiento.Text = "Asiento";
            // 
            // numUpAsiento
            // 
            this.numUpAsiento.Location = new System.Drawing.Point(128, 173);
            this.numUpAsiento.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numUpAsiento.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpAsiento.Name = "numUpAsiento";
            this.numUpAsiento.Size = new System.Drawing.Size(39, 20);
            this.numUpAsiento.TabIndex = 17;
            this.numUpAsiento.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtNombrePasajero
            // 
            this.txtNombrePasajero.Location = new System.Drawing.Point(13, 173);
            this.txtNombrePasajero.Name = "txtNombrePasajero";
            this.txtNombrePasajero.Size = new System.Drawing.Size(100, 20);
            this.txtNombrePasajero.TabIndex = 18;
            // 
            // gbDestino
            // 
            this.gbDestino.Controls.Add(this.lblNombreDestino);
            this.gbDestino.Controls.Add(this.cmbDestino);
            this.gbDestino.Controls.Add(this.txtCosto);
            this.gbDestino.Controls.Add(this.lblCosto);
            this.gbDestino.Controls.Add(this.txtDuracion);
            this.gbDestino.Controls.Add(this.lblDuracion);
            this.gbDestino.Location = new System.Drawing.Point(12, 51);
            this.gbDestino.Name = "gbDestino";
            this.gbDestino.Size = new System.Drawing.Size(200, 100);
            this.gbDestino.TabIndex = 19;
            this.gbDestino.TabStop = false;
            this.gbDestino.Text = "Destino";
            // 
            // lblNombreDestino
            // 
            this.lblNombreDestino.AutoSize = true;
            this.lblNombreDestino.Location = new System.Drawing.Point(123, 22);
            this.lblNombreDestino.Name = "lblNombreDestino";
            this.lblNombreDestino.Size = new System.Drawing.Size(44, 13);
            this.lblNombreDestino.TabIndex = 15;
            this.lblNombreDestino.Text = "Nombre";
            // 
            // frmVentaBoletos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 317);
            this.Controls.Add(this.gbDestino);
            this.Controls.Add(this.txtNombrePasajero);
            this.Controls.Add(this.numUpAsiento);
            this.Controls.Add(this.lblAsiento);
            this.Controls.Add(this.lblNombrePasajero);
            this.Controls.Add(this.txtNumeroBoleto);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.lblNumBoleto);
            this.Controls.Add(this.gbTipoBoleto);
            this.Controls.Add(this.label1);
            this.Name = "frmVentaBoletos";
            this.Text = "Venta Boletos";
            this.Load += new System.EventHandler(this.frmVentaBoletos_Load);
            this.gbTipoBoleto.ResumeLayout(false);
            this.gbTipoBoleto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpAsiento)).EndInit();
            this.gbDestino.ResumeLayout(false);
            this.gbDestino.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdNormal;
        private System.Windows.Forms.RadioButton rdEstudiante;
        private System.Windows.Forms.GroupBox gbTipoBoleto;
        private System.Windows.Forms.Label lblNumBoleto;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.TextBox txtNumeroBoleto;
        private System.Windows.Forms.ComboBox cmbDestino;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblDuracion;
        private System.Windows.Forms.TextBox txtCosto;
        private System.Windows.Forms.TextBox txtDuracion;
        private System.Windows.Forms.Label lblNombrePasajero;
        private System.Windows.Forms.Label lblAsiento;
        private System.Windows.Forms.NumericUpDown numUpAsiento;
        private System.Windows.Forms.TextBox txtNombrePasajero;
        private System.Windows.Forms.GroupBox gbDestino;
        private System.Windows.Forms.Label lblNombreDestino;
    }
}