﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyBoletos
{
    public class AdmDestino
    {
        //USO DE DICTIONARY
        private Dictionary<string, Destino> dicDestinos =new Dictionary<string, Destino>();


        //METODO PARA AGREGAR DESTINOS 
        public void AgregarDestino(string clave, string nombreDestino, int costo, double tiempoTrayecto)
        {
            dicDestinos.Add(clave, new Destino(nombreDestino, costo, tiempoTrayecto));
        }

        //Buscar clave destino

        public bool BuscaClave(string clave)
        {
            return dicDestinos.ContainsKey(clave);
        }

        public string[] ObtenClavesDestino()
        {
            string[] claves = new string[dicDestinos.Count];
            int pos = 0;
            foreach(KeyValuePair<string, Destino> kvp in dicDestinos)
            {
                claves[pos] = kvp.Key;
                pos++;
            }

            return claves;
        }

        //METODO PARA OBTENER DESTINOS
        public Destino ObtenDestino(string clave)
        {
            return dicDestinos[clave];
        }

        

    }
}
