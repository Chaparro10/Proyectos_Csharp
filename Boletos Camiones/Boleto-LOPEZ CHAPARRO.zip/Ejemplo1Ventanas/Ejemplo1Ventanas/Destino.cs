﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyBoletos
{
    public class Destino
    {
        private string NombreDestino;
        private int Costo;
        private double TiempoTrayecto;

        public Destino(string nombreDestino, int costo, double tiempo)
        {
            NombreDestino = nombreDestino;
            Costo = costo;
            TiempoTrayecto = tiempo;
        }

        public string pNombreDestino
        {
            get
            {
                return NombreDestino;
            }
            set
            {
                NombreDestino = value;
            }
        }

        public int pCostoDestino
        {
            get
            {
                return Costo;
            }
            set
            {
                Costo = value;
            }
        }

        public double pTiempoTrayecto
        {
            get
            {
                return TiempoTrayecto;
            }
            set
            {
                TiempoTrayecto = value;
            }
        }
    }
}
