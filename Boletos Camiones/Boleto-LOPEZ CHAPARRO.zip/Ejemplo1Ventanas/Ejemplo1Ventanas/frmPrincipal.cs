﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyBoletos
{
    public partial class frmPrincipal : Form
    {
        AdmBoletos boletos;
        AdmDestino destinos;
        public frmPrincipal(AdmBoletos bol,AdmDestino ad)
        {
            InitializeComponent();
            boletos = bol;
            destinos = ad;


        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 agregaDestinos = new Form1(destinos,boletos);
            agregaDestinos.ShowDialog();
        }

        private void venderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVentaBoletos VenderBoletos = new frmVentaBoletos(boletos,destinos);
            VenderBoletos.ShowDialog();
        }
    }
}
